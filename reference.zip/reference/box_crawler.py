# %%
import requests
from bs4 import BeautifulSoup

# %%
def get_content(boxurl):
    response = requests.get(url=boxurl)
    # 200 is normal
    # print("Check the status code", response.status_code)
    soup = BeautifulSoup(response.text, "lxml")
    all_records = soup.find_all("tr")
    records = []
    for line in all_records:
        columns = line.contents
        one = []
        for c in columns:
            processed_c = c.text.replace(",","").replace("$", "").strip()
            one.append(processed_c)
        records.append(one)
    return records

def write_file(contents, target_file):
    with open(target_file, "a+") as f:
        for c in contents:
            f.write(",".join(c)+"\n")
    print("Finished", len(contents))

# url = "https://www.boxofficemojo.com/chart/ww_top_lifetime_gross/?area=XWW"
# contents = get_content(url)
# write_file(contents=contents, target_file="./rank_list.txt")

# %%
if __name__ == "main":
    main_url = "https://www.boxofficemojo.com/chart/ww_top_lifetime_gross/?area=XWW&offset="
    target = "./rank_list.txt"
    for page in range(0, 2000, 200):
        page_url = main_url + str(page)
        contents = get_content(page_url)
        if page>0:
            contents = contents[1:]
        write_file(contents=contents, target_file=target)

# %%
    import pandas as pd
    x = pd.read_csv(target)
    x.head()
