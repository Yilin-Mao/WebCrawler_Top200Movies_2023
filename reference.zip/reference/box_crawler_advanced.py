# %%
import pandas as pd
import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
# %%
def get_content(boxurl):
    response = requests.get(url=boxurl)
    # 200 is normal
    # print("Check the status code", response.status_code)
    soup = BeautifulSoup(response.text, "html.parser")
    all_trs = soup.find_all("tr")
    # all_trs = ["<tr>...</tr>","<tr>...</tr>","<tr>...</tr>",...,"<tr>...</tr>"]
    records = []
    for one_tr in all_trs:
        one = []
        contents = one_tr.contents
        # contents = [<th>...</th>,<th>...</th>,...,<th>...</th>"]
        for one_tag in contents:
            processed_c = one_tag.text.replace(",","").replace("$", "").strip()
            one.append(processed_c)
        records.append(one)
    return records

# %%
def get_content_regex(boxurl, page=0):
    response = requests.get(url=boxurl)
    # 200 is normal
    # print("Check the status code", response.status_code)
    soup = BeautifulSoup(response.text, "html.parser")
    all_trs = soup.find_all("tr")
    # all_trs = ["<tr>...</tr>","<tr>...</tr>","<tr>...</tr>",...,"<tr>...</tr>"]
    records = []
    pat = re.compile("([^>\\n]+?)<")
    for one_tr in all_trs:
        one = []
        html_block = str(one_tr)
        match_res = re.findall(pat, html_block)
        for one_column in match_res:
            processed_c = one_column.replace(",","").replace("$", "").strip()
            one.append(processed_c)
        records.append(one)
    if page>0:
        return records[1:], page
    return records, page

# %%

def write_file(contents, target_file):
    with open(target_file, "a+", encoding='utf-8') as f:
        for c in contents:
            f.write(",".join(c)+"\n")
    print("\t Finished writing >", len(contents))

# url = "https://www.boxofficemojo.com/chart/ww_top_lifetime_gross/?area=XWW"
# contents = get_content(url)
# write_file(contents=contents, target_file="./rank_list.txt")

# %%
if __name__ == "__main__":
    print("\n>>>>>>> Checking Regex")
    pat = re.compile("([^>\\n]+?)<")
    test_string = '''<tr><td class="a-text-right mojo-header-column mojo-truncate mojo-field-type-rank" style="width: 61px; height: 34px; min-width: 61px; min-height: 34px;">1</td><td class="a-text-left mojo-field-type-title" style="width: 217px; height: 34px; min-width: 217px; min-height: 34px;"><a class="a-link-normal" href="/title/tt0499549/?ref_=bo_cso_table_1">Avatar</a></td><td class="a-text-right mojo-field-type-money" style="width: 151px; height: 34px; min-width: 151px; min-height: 34px;">$2,923,706,026</td><td class="a-text-right mojo-field-type-money" style="width: 139px; height: 34px; min-width: 139px; min-height: 34px;">$785,221,649</td><td class="a-text-right mojo-field-type-percent" style="width: 106px; height: 34px; min-width: 106px; min-height: 34px;">26.9%</td><td class="a-text-right mojo-field-type-money" style="width: 144px; height: 34px; min-width: 144px; min-height: 34px;">$2,138,484,377</td><td class="a-text-right mojo-field-type-percent" style="width: 95px; height: 34px; min-width: 95px; min-height: 34px;">73.1%</td><td class="a-text-left mojo-field-type-year" style="width: 61px; height: 34px; min-width: 61px; min-height: 34px;"><a class="a-link-normal" href="/year/world/2009/?ref_=bo_cso_table_1">2009</a></td></tr>'''
    res = re.findall(pattern=pat, string=test_string)
    print(res)

    # %%
    print("\n>>>>>>> Downloading the rank list2 from parallel crawlers")
    main_url = "https://www.boxofficemojo.com/chart/ww_top_lifetime_gross/?area=XWW&offset="
    target = "./rank_list_2.txt"
    with ThreadPoolExecutor(8) as exe:
        workers = []
        for p, page in enumerate(range(0, 2000, 200)):
            page_url = main_url + str(page)
            # contents = get_content(page_url)
            worker = exe.submit(get_content_regex, page_url, p)
            workers.append(worker)
        for worker in as_completed(workers):
            contents, page = worker.result()
            print("\tFinished Page >", page)
            write_file(contents=contents, target_file=target)
    x = pd.read_csv(target)
    print(x.head())

    # %%
    print("\n>>>>>>> Downloading an Image to the test_img.jpg")
    import requests
    r = requests.get("https://m.media-amazon.com/images/M/MV5BZDA0OGQxNTItMDZkMC00N2UyLTg3MzMtYTJmNjg3Nzk5MzRiXkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_SY278_CR2,0,184,278_.jpg")
    print("10 Bytes", r.content[:10])
    # r.content is the bytes of images
    # b'\xff\xd8\xff\xe0\x00\x10JFIF'
    with open("./test_img.jpg", 'wb') as f:
        f.write(r.content)

    print("\n>>>>>>> List Formating to CSV")
    v = ['1', 'Avatar', '2923706026', '785221649', '26.9%', '2138484377', '73.1%', '2009']
    row = ",".join(v)+"\n"
    # '1,Avatar,2923706026,785221649,26.9%,2138484377,73.1%,2009\n'
    print(row)
